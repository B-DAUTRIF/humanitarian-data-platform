# Audit machine HDP V6.0.0

Contrôles: **53** · réussis: **53** · échecs bloquants: **0**.

## Matrice fonctionnelle

| Domaine | Composant | Vue UI | État |
|---|---|---|---|
| federated_search | `source/payload/api/app/federated_search.py` | `search` | OK |
| data_grid_signals | `source/payload/api/app/v5_features.py` | `intelligence` | OK |
| source_specific_settings | `source/payload/api/app/source_registry.py` | `source-settings` | OK |
| api_inventory | `source/payload/api/app/api_inventory.py` | `inventory` | OK |
| projects_preferences | `source/payload/api/app/main.py` | `projects` | OK |
| github_project_sync | `source/payload/api/app/github_sync.py` | `projects` | OK |
| cod_m49_hdx | `source/payload/api/app/project_integrations.py` | `projects` | OK |
| local_library | `source/payload/api/app/local_library.py` | `data` | OK |
| rss | `source/payload/api/app/rss_registry.py` | `rss` | OK |
| spip | `source/payload/api/app/spip_bridge.py` | `spip` | OK |
| mail | `source/payload/api/app/mail_features.py` | `mail` | OK |
| map | `source/payload/api/app/map_utils.py` | `map` | OK |
| scripts_python_r | `source/payload/api/app/script_runtime.py` | `scripts` | OK |
| notebooks | `source/payload/api/app/main.py` | `notebooks` | OK |
| schedules | `source/payload/api/app/scheduler_utils.py` | `schedules` | OK |
| timeline | `source/payload/api/app/v6_timeline.py` | `timeline` | OK |
| sql_readonly | `source/payload/api/app/sql_workspace.py` | `sql` | OK |
| backups | `source/payload/api/app/v6_backup.py` | `backups` | OK |
| rules | `source/payload/api/app/v6_rules.py` | `intelligence` | OK |
| actions | `source/payload/api/app/v6_actions.py` | `actions` | OK |
| data_jobs | `source/payload/api/app/v6_data_jobs.py` | `actions` | OK |
| passkey_auth | `source/payload/api/app/passkey_auth.py` | `home` | OK |
| technology_code_docs | `source/payload/api/app/technology_registry.py` | `technologies` | OK |
| r_service | `source/payload/r-service/Dockerfile` | `scripts` | OK |
| spip_plugin | `source/spip-plugin/hdp/paquet.xml` | `spip` | OK |
| python_client | `clients-v6/python/pyproject.toml` | `technologies` | OK |
| r_client | `clients-v6/R/DESCRIPTION` | `technologies` | OK |

## Contrôles

| Contrôle | Résultat | Détail |
|---|---|---|
| backend version native | OK | APP_VERSION doit être 6.0.0 |
| registry version native | OK | source_registry est encore ancien |
| user-agent V6 | OK | user_agent du registre doit être HDP/6.0.0 |
| Docker V6 entrypoint | OK | Docker doit démarrer main_v6 |
| UI release label | OK | l'interface contient encore 6.0.0-dev |
| backend release label | OK | main.py contient encore 6.0.0-dev |
| installer source V6 | OK | installer.c n'est pas exclusivement V6 |
| installer resources V6 | OK | installer.rc n'est pas V6 |
| Windows build V6 | OK | build-windows.ps1 contient une version antérieure |
| UI unique element IDs | OK | IDs dupliqués: [] |
| navigation points to existing views | OK | navigation orpheline: [] |
| all user views reachable | OK | vues sans onglet: [] |
| all required V6 views | OK | vues manquantes: [] |
| all required V6 tabs | OK | onglets manquants: [] |
| Simple/Avancé/Expert modes | OK | modes repérés: ['avancé', 'expert', 'simple'] |
| FastAPI OpenAPI generation | OK | 147 chemins |
| essential backend routes mounted | OK | routes absentes: [] |
| UI API calls resolve to backend | OK | appels UI non résolus: [] |
| inventory covers all searchable connectors | OK | inventaire=['dhs', 'gdacs', 'hdx', 'hdx-hapi', 'reliefweb', 'un-sdg', 'unhcr', 'unicef-sdmx', 'who-gho', 'world-bank-health'], registre=['dhs', 'gdacs', 'hdx', 'hdx-hapi', 'reliefweb', 'un-sdg', 'unhcr', 'unicef-sdmx', 'who-gho', 'world-bank-health'] |
| inventory keys unique | OK | doublons=0 |
| all connector schema fields in inventory | OK | absents=[] |
| inventory has executable and informational classifications | OK | supported=228, information=792 |
| function:federated_search | OK | component=True, ui=True |
| function:data_grid_signals | OK | component=True, ui=True |
| function:source_specific_settings | OK | component=True, ui=True |
| function:api_inventory | OK | component=True, ui=True |
| function:projects_preferences | OK | component=True, ui=True |
| function:github_project_sync | OK | component=True, ui=True |
| function:cod_m49_hdx | OK | component=True, ui=True |
| function:local_library | OK | component=True, ui=True |
| function:rss | OK | component=True, ui=True |
| function:spip | OK | component=True, ui=True |
| function:mail | OK | component=True, ui=True |
| function:map | OK | component=True, ui=True |
| function:scripts_python_r | OK | component=True, ui=True |
| function:notebooks | OK | component=True, ui=True |
| function:schedules | OK | component=True, ui=True |
| function:timeline | OK | component=True, ui=True |
| function:sql_readonly | OK | component=True, ui=True |
| function:backups | OK | component=True, ui=True |
| function:rules | OK | component=True, ui=True |
| function:actions | OK | component=True, ui=True |
| function:data_jobs | OK | component=True, ui=True |
| function:passkey_auth | OK | component=True, ui=True |
| function:technology_code_docs | OK | component=True, ui=True |
| function:r_service | OK | component=True, ui=True |
| function:spip_plugin | OK | component=True, ui=True |
| function:python_client | OK | component=True, ui=True |
| function:r_client | OK | component=True, ui=True |
| installer:environment scan | OK | fonction introuvable dans installer.c |
| installer:Docker | OK | fonction introuvable dans installer.c |
| installer:Windows shortcut/menu | OK | fonction introuvable dans installer.c |
| installer:installation log | OK | fonction introuvable dans installer.c |
