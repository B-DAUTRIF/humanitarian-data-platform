# Livrables et empreintes

Les livrables courants sont dans [`dist/v2.0`](../dist/v2.0). Les fichiers historiques originaux sont conservés dans [`dist/v1.5`](../dist/v1.5).

## Version 2.0

| Fichier | Rôle |
|---|---|
| `HumanitarianDataPlatform_Setup_Native_GUI_v2.0.exe` | Installateur Windows natif x64 |
| `HumanitarianDataPlatform_Setup_Native_GUI_v2.0.exe.sha256` | Empreinte de l'installateur |
| `HumanitarianDataPlatform_Windows_v2.0.zip` | Paquet utilisateur Windows |
| `HumanitarianDataPlatform_Source_v2.0.zip` | Sources reproductibles |
| `HumanitarianDataPlatform_Archive_complete_v2.0.zip` | Archive complète de remise |
| `HumanitarianDataPlatform_Archive_complete_v2.0.zip.sha256` | Empreinte de l'archive complète |
| `HumanitarianDataPlatform_Setup_README_v2.0.txt` | Notice courte |
| `HDP_Diagnostic_v2.0.cmd` | Diagnostic Windows borné |
| `Notice_detaillee_Humanitarian_Data_Platform_v2.0.pdf` | Notice détaillée A4 |
| `HDP_Prompt_exhaustif_reprise_GPT_Plus_v2.0.txt` | Prompt autonome de reprise |
| `MANIFESTE_HumanitarianDataPlatform_v2.0.txt` | Constitution et validations |
| `SHA256SUMS.txt` | Empreintes de tous les livrables v2.0 hors lui-même |

Les tailles et valeurs définitives sont consignées dans `dist/v2.0/SHA256SUMS.txt`, généré après la construction des archives.

## Validation

```bash
cd dist/v2.0
sha256sum -c SHA256SUMS.txt
unzip -t HumanitarianDataPlatform_Source_v2.0.zip
unzip -t HumanitarianDataPlatform_Windows_v2.0.zip
unzip -t HumanitarianDataPlatform_Archive_complete_v2.0.zip
```
